import React, { useState } from 'react';
import api from '../api';

function Login({ onLogin }) {
  const [usuario, setUsuario] = useState('');
  const [contrasena, setContrasena] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/login', { usuario, contrasena });
      onLogin(res.data.token);
    } catch (err) {
      alert('Credenciales inválidas ❌');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input value={usuario} onChange={(e) => setUsuario(e.target.value)} placeholder="Usuario" />
      <input type="password" value={contrasena} onChange={(e) => setContrasena(e.target.value)} placeholder="Contraseña" />
      <button type="submit">Ingresar</button>
    </form>
  );
}

export default Login;
